﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Messages;
using System.Runtime.Serialization;

namespace LucasDemoCrm
{
    /// <summary>
    /// Wrapper class for the Xrm.Sdk.Messages.RetrieveAttributeResponse class. Primarily used to support Moq injection during testing.
    /// </summary>
    [DataContract(Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts")]
    public class RetrieveAttributeResponseWrapper : OrganizationResponse
    {
        private AttributeMetadata _metadata;
        public RetrieveAttributeResponseWrapper(OrganizationResponse response)
        {

            try
            {
                _metadata = ((RetrieveAttributeResponseWrapper)response).AttributeMetadata;
            }
            catch
            {
                _metadata = ((RetrieveAttributeResponse)response).AttributeMetadata;
            }
        }

        public AttributeMetadata AttributeMetadata
        {
            get
            {
                return _metadata;
            }
            set
            {
                _metadata = value;
            }
        }
    }
}
