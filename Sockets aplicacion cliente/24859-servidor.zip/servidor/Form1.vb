﻿Imports System
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports Microsoft.VisualBasic
Public Class TCPSERVIDOR

    Public servidor As TcpListener = Nothing ''servidor de escucha
    Public ip As IPAddress = Nothing '' ip del servidor
    Public port As Integer = Nothing '' puerto por el que realiza la escucha
    Public cliente As TcpClient = Nothing  '' cliente conectado(aceptamos la solicitud y asignamos el tcpclient)
    Public leer_escribir As NetworkStream = Nothing '' metodo para enviar y recibir informacion desde cliente

    Public bytes() As Byte '' donde almacenamos lo recibido o lo que vamos a enviar
    Public cadena As String = "" ''almacenamos la info antes de codificar o bien despues para tratarla
    Public max_connect As Integer = 10 '' maximas conexiones permitidas
    Public conectados = 0 '' usuarios conectados
    Public idclientes(max_connect) As IntPtr '' array de identificadores de clientes
    Public tcpclientes(max_connect) As TcpClient '' array de tcpclient de los clientes
    Public posicion As Integer = 0
    Private Sub escucha_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles escucha.CheckedChanged

        Try
            '' indicamos ip y puerto
            ip = IPAddress.Parse("127.0.0.1")
            port = 6000
            '' asignamos un nuevo tcplistener a servidor
            servidor = New TcpListener(ip, port)
            servidor.Start() ''inicializamos el modo escucha
            ''
            While True
                '' preguntamos si existen solicitudes pendientes
                '' y posteriormente se acepta y luego se controla si se mantiene
                If servidor.Pending() = True Then
                    cliente = servidor.AcceptTcpClient
                    If conectados < max_connect Then
                        conectados += 1
                        ''guardamos info del cliente
                        idclientes(posicion) = cliente.Client.Handle.ToString
                        usuarios.Text &= "********************************************" & vbCrLf
                        usuarios.Text &= "[ID] " & idclientes(posicion).ToString & "     " & "[DT] " & Date.Now & vbCrLf
                        tcpclientes(posicion) = cliente
                        mandar_usuarios()
                        'If posicion = 0 Then
                        'End If
                        secuencia_lecturas.Interval = 1000
                        secuencia_lecturas.Start()
                        posicion += 1
                    Else
                        noconnect(cliente)
                    End If
                End If
                ''esperamos cualquier escritura en el servidor 


                System.Windows.Forms.Application.DoEvents()
            End While
        Catch ex As Exception

        End Try
       
    End Sub
    Public Sub noconnect(ByRef cliente As TcpClient)
        cadena = "Servidor Saturado" & vbCrLf
        bytes = Encoding.ASCII.GetBytes(cadena)
        leer_escribir = cliente.GetStream
        leer_escribir.Write(bytes, 0, bytes.Length)

        leer_escribir.Flush()

        leer_escribir = Nothing
        bytes = Nothing
        cadena = ""

        cliente.Close()
    End Sub
    Public Sub mandar_usuarios()
        Dim i As Integer
        Dim j As Integer
        '' almacenar lista usuarios en cadena
        For j = 0 To posicion Step 1
            cadena &= "U.[ID] - " & idclientes(j).ToString & vbCrLf
        Next
        For i = 0 To posicion Step 1
            ''meter en cadena todos los id
            leer_escribir = tcpclientes(i).GetStream
            bytes = Encoding.ASCII.GetBytes(cadena)
            leer_escribir.Write(bytes, 0, bytes.Length)
        Next
        cadena = ""
        bytes = Nothing
        leer_escribir = Nothing
    End Sub
    Private Sub secuencia_lecturas_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles secuencia_lecturas.Tick
        Dim i As Integer
        Dim j As Integer
        For i = 0 To posicion - 1 Step 1
            leer_escribir = tcpclientes(i).GetStream
            If leer_escribir.DataAvailable = True Then
                ReDim bytes(cliente.ReceiveBufferSize)
                leer_escribir.Read(bytes, 0, bytes.Length)
                cadena &= vbCrLf & cliente.Client.Handle.ToString
                cadena &= "  DICE :" & Encoding.ASCII.GetString(bytes)
                cadena &= vbCrLf
                For j = 0 To posicion - 1 Step 1
                    leer_escribir = tcpclientes(j).GetStream
                    bytes = Encoding.ASCII.GetBytes(cadena)
                    leer_escribir.Write(bytes, 0, bytes.Length)
                Next
                cadena = ""
                bytes = Nothing
                leer_escribir = Nothing
            End If
        Next
    End Sub
End Class