﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TCPSERVIDOR
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.escucha = New System.Windows.Forms.CheckBox
        Me.usuarios = New System.Windows.Forms.TextBox
        Me.secuencia_lecturas = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'escucha
        '
        Me.escucha.AutoSize = True
        Me.escucha.Location = New System.Drawing.Point(12, 11)
        Me.escucha.Name = "escucha"
        Me.escucha.Size = New System.Drawing.Size(99, 17)
        Me.escucha.TabIndex = 0
        Me.escucha.Text = "Poner Escucha"
        Me.escucha.UseVisualStyleBackColor = True
        '
        'usuarios
        '
        Me.usuarios.Location = New System.Drawing.Point(12, 34)
        Me.usuarios.Multiline = True
        Me.usuarios.Name = "usuarios"
        Me.usuarios.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.usuarios.Size = New System.Drawing.Size(148, 255)
        Me.usuarios.TabIndex = 2
        '
        'secuencia_lecturas
        '
        '
        'TCPSERVIDOR
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(174, 299)
        Me.Controls.Add(Me.usuarios)
        Me.Controls.Add(Me.escucha)
        Me.Name = "TCPSERVIDOR"
        Me.Text = "TCPSERVIDOR"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents escucha As System.Windows.Forms.CheckBox
    Friend WithEvents usuarios As System.Windows.Forms.TextBox
    Friend WithEvents secuencia_lecturas As System.Windows.Forms.Timer

End Class
